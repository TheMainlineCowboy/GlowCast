import { useMemo, useRef, useState } from 'react';
import { Download, Eraser, ImagePlus, Layers, Maximize, Sparkles, Wand2 } from 'lucide-react';

type Zone = {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  included: boolean;
};

type Effect = 'haunt' | 'snow' | 'neon' | 'fire' | 'grid';

const effects: { id: Effect; label: string; description: string }[] = [
  { id: 'haunt', label: 'Haunted Windows', description: 'glowing eyes, lightning, smoke' },
  { id: 'snow', label: 'Snowfall', description: 'soft holiday snow pass' },
  { id: 'neon', label: 'Neon Glow', description: 'business sign / logo feel' },
  { id: 'fire', label: 'Fire Glow', description: 'warm flickering projection' },
  { id: 'grid', label: 'Alignment Grid', description: 'line projector back up later' },
];

function App() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [zones, setZones] = useState<Zone[]>([]);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [effect, setEffect] = useState<Effect>('haunt');
  const [invert, setInvert] = useState(false);
  const [watermark, setWatermark] = useState(true);
  const stageRef = useRef<HTMLDivElement | null>(null);

  const selectedZone = useMemo(() => zones.find((z) => z.id === selectedZoneId) ?? null, [zones, selectedZoneId]);

  const onImage = (file?: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setImageUrl(url);
    setZones([]);
    setSelectedZoneId(null);
  };

  const addZone = () => {
    const newZone: Zone = {
      id: crypto.randomUUID(),
      x: 28 + zones.length * 3,
      y: 24 + zones.length * 3,
      w: 18,
      h: 18,
      included: true,
    };
    setZones((prev) => [...prev, newZone]);
    setSelectedZoneId(newZone.id);
  };

  const updateZone = (id: string, patch: Partial<Zone>) => {
    setZones((prev) => prev.map((z) => (z.id === id ? { ...z, ...patch } : z)));
  };

  const removeSelected = () => {
    if (!selectedZoneId) return;
    setZones((prev) => prev.filter((z) => z.id !== selectedZoneId));
    setSelectedZoneId(null);
  };

  const fakeAiDetect = () => {
    // Placeholder for future AI segmentation. These rectangles demonstrate the intended UX.
    const suggested: Zone[] = [
      { id: crypto.randomUUID(), x: 15, y: 22, w: 18, h: 24, included: true },
      { id: crypto.randomUUID(), x: 42, y: 20, w: 17, h: 24, included: true },
      { id: crypto.randomUUID(), x: 68, y: 22, w: 18, h: 24, included: true },
      { id: crypto.randomUUID(), x: 36, y: 56, w: 28, h: 26, included: false },
    ];
    setZones(suggested);
    setSelectedZoneId(suggested[0].id);
  };

  const exportAlignmentGuide = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1920;
    canvas.height = 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#050714';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#2de2e6';
    ctx.lineWidth = 2;
    for (let x = 0; x <= canvas.width; x += 120) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= canvas.height; y += 120) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    zones.forEach((zone, index) => {
      const x = (zone.x / 100) * canvas.width;
      const y = (zone.y / 100) * canvas.height;
      const w = (zone.w / 100) * canvas.width;
      const h = (zone.h / 100) * canvas.height;
      ctx.strokeStyle = zone.included ? '#fff56b' : '#ff4d6d';
      ctx.lineWidth = 6;
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = zone.included ? '#fff56b' : '#ff4d6d';
      ctx.font = 'bold 42px Arial';
      ctx.fillText(`Zone ${index + 1}`, x + 20, y + 55);
    });

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 54px Arial';
    ctx.fillText('GlowCast Alignment Guide', 60, canvas.height - 80);

    const link = document.createElement('a');
    link.download = 'glowcast-alignment-guide.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <main className="appShell">
      <section className="heroPanel">
        <div>
          <p className="eyebrow">GlowCast Prototype</p>
          <h1>Projection mapping made stupid simple.</h1>
          <p className="subtitle">Import a photo, mark the areas to project on or around, choose an effect, then export an alignment guide.</p>
        </div>
        <label className="uploadButton">
          <ImagePlus size={20} />
          Upload Surface Photo
          <input type="file" accept="image/*" onChange={(e) => onImage(e.target.files?.[0])} />
        </label>
      </section>

      <section className="workspace">
        <aside className="toolPanel">
          <div className="panelBlock">
            <h2>1. Mapping</h2>
            <button onClick={fakeAiDetect} disabled={!imageUrl} className="primary"><Wand2 size={18} /> Dummy AI Detect</button>
            <button onClick={addZone} disabled={!imageUrl}><Layers size={18} /> Add Manual Zone</button>
            <button onClick={() => setInvert((v) => !v)} disabled={!imageUrl}><Sparkles size={18} /> {invert ? 'Project Selected Areas' : 'Invert / Project Around'}</button>
            <button onClick={removeSelected} disabled={!selectedZoneId}><Eraser size={18} /> Remove Selected</button>
          </div>

          <div className="panelBlock">
            <h2>2. Effect</h2>
            <div className="effectList">
              {effects.map((item) => (
                <button key={item.id} onClick={() => setEffect(item.id)} className={effect === item.id ? 'activeEffect' : ''}>
                  <strong>{item.label}</strong>
                  <span>{item.description}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="panelBlock">
            <h2>3. Export</h2>
            <button onClick={exportAlignmentGuide} disabled={!imageUrl}><Download size={18} /> Export Alignment Guide</button>
            <label className="toggle"><input type="checkbox" checked={watermark} onChange={(e) => setWatermark(e.target.checked)} /> Free watermark preview</label>
          </div>
        </aside>

        <section className="stageWrap">
          <div ref={stageRef} className={`stage effect-${effect} ${invert ? 'invertMode' : ''}`}>
            {!imageUrl && (
              <div className="emptyState">
                <Maximize size={46} />
                <h2>Upload a wall, house, garage, storefront, or stage photo.</h2>
                <p>This prototype starts with manual/dummy masking. Real AI segmentation comes later.</p>
              </div>
            )}
            {imageUrl && <img src={imageUrl} alt="Projection surface" />}
            {zones.map((zone, index) => (
              <button
                key={zone.id}
                className={`zone ${zone.included ? 'included' : 'excluded'} ${selectedZoneId === zone.id ? 'selected' : ''}`}
                style={{ left: `${zone.x}%`, top: `${zone.y}%`, width: `${zone.w}%`, height: `${zone.h}%` }}
                onClick={() => setSelectedZoneId(zone.id)}
              >
                <span>{index + 1}</span>
              </button>
            ))}
            {watermark && <div className="watermark">GlowCast Free Preview</div>}
          </div>

          {selectedZone && (
            <div className="zoneEditor">
              <strong>Selected Zone</strong>
              <label>X <input type="range" min="0" max="95" value={selectedZone.x} onChange={(e) => updateZone(selectedZone.id, { x: Number(e.target.value) })} /></label>
              <label>Y <input type="range" min="0" max="95" value={selectedZone.y} onChange={(e) => updateZone(selectedZone.id, { y: Number(e.target.value) })} /></label>
              <label>W <input type="range" min="5" max="80" value={selectedZone.w} onChange={(e) => updateZone(selectedZone.id, { w: Number(e.target.value) })} /></label>
              <label>H <input type="range" min="5" max="80" value={selectedZone.h} onChange={(e) => updateZone(selectedZone.id, { h: Number(e.target.value) })} /></label>
              <button onClick={() => updateZone(selectedZone.id, { included: !selectedZone.included })}>{selectedZone.included ? 'Mark Excluded' : 'Mark Included'}</button>
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

export default App;
